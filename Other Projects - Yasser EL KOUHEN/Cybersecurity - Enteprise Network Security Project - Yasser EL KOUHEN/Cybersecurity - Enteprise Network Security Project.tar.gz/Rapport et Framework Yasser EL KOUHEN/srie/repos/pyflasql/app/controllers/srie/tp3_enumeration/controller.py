# This file is part of PyFlaSQL.
# Original author: Raphael Viera (raphael.viera@emse.fr)
# Contribution : ISMIN student X (ismin.student@etu.emse.fr)
# License: check the LICENSE file.
"""
Implements the logic for TP3 - Enumeration
"""
from flask import Flask, render_template, url_for, redirect, request
from flask_login import UserMixin, login_user, LoginManager, login_required, logout_user, current_user
from flask_sqlalchemy import SQLAlchemy
# from flask_migrate import Migrate
from ....models.sql import db, UserDB
from ...utils import get_shell_output
from ....models.srie.tp3_enumeration.forms import Enum4LinuxForm, NBTSCanForm, BannerGrabbingForm
import subprocess 

@login_required
def srie_tp3_enumeration():
    """
        Logic for /srie/tp3_enumeration/home
        Login is required to view this page

        Args:
            - None.

        Returns:
            - rendered template view/templates/srie/tp3_enumeration/home.html
        """
    username = current_user.username
    return render_template(url_for('blueprint.srie_tp3_enumeration')+'.html', username=username)

    # This file is part of PyFlaSQL.
# Original author: Raphael Viera (raphael.viera@emse.fr)
# Contribution: ISMIN student X (ismin.student@etu.emse.fr)
# License: check the LICENSE file.

def srie_tp3_enum4linux():
    """
    Handles the logic for the enum4linux tool.
    Args:
    - None.
    Returns:
    - Rendered HTML template for enum4linux with results.
    """
    form = Enum4LinuxForm()
    enum_result = None
    command_executed = None

    if form.validate_on_submit():
        target = form.target.data
        try:
            # Prepare the command
            command_executed = f"enum4linux -a {target}"
            # Execute the enum4linux command
            enum_result = subprocess.getoutput(command_executed)
        except Exception as e:
            enum_result = f"An error occurred: {str(e)}"

    return render_template(
        'srie/tp3_enumeration/enum4linux.html',
        form=form,
        command_executed=command_executed,
        command_output=enum_result
    )

def srie_tp3_nbtscan():
    """
    Handles the logic for the NetBIOS Scan tool.
    """
    form = NBTSCanForm()
    nbtscan_result = None
    command_executed = None

    if form.validate_on_submit():
        target_range = form.target_range.data
        try:
            # Préparer et exécuter la commande nbtscan
            command_executed = f"nbtscan {target_range}"
            nbtscan_result = subprocess.getoutput(command_executed)
        except Exception as e:
            nbtscan_result = f"An error occurred: {str(e)}"

    return render_template(
        'srie/tp3_enumeration/nbtscan.html',
        form=form,
        command_executed=command_executed,
        command_output=nbtscan_result
    )

def srie_tp3_banner_grabbing():
    """
    Handles the logic for the Banner Grabbing tool using Telnet.
    """
    form = BannerGrabbingForm()
    banner_result = None
    command_executed = None

    if form.validate_on_submit():
        target = form.target.data
        port = form.port.data
        try:
            # Préparer et exécuter la commande Telnet
            command_executed = f"echo | telnet {target} {port}"
            banner_result = subprocess.getoutput(command_executed)
        except Exception as e:
            banner_result = f"An error occurred: {str(e)}"

    return render_template(
        'srie/tp3_enumeration/banner_grabbing.html',
        form=form,
        command_executed=command_executed,
        command_output=banner_result
    )