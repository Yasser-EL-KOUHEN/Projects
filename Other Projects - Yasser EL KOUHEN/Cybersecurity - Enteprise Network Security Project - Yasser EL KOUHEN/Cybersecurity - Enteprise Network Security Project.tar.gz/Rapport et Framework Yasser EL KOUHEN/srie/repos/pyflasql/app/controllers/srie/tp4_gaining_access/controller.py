# This file is part of PyFlaSQL.
# Original author: Raphael Viera (raphael.viera@emse.fr)
# Contribution : ISMIN student X (ismin.student@etu.emse.fr)
# License: check the LICENSE file.
"""
Implements the logic for TP4 - Gaining Access
"""
from flask import Flask, render_template, url_for, redirect, request
from flask_login import UserMixin, login_user, LoginManager, login_required, logout_user, current_user
from flask_sqlalchemy import SQLAlchemy
# from flask_migrate import Migrate
from ....models.sql import db, UserDB
from ...utils import get_shell_output
from ....models.srie.tp4_gaining_access.forms import SSHForm, FTPForm
import subprocess

@login_required
def srie_tp4_gaining_access():
    """
        Logic for /srie/tp4_gaining_access/home
        Login is required to view this page

        Args:
            - None.

        Returns:
            - rendered template view/templates/srie/tp4_gaining_access/home.html
        """
    username = current_user.username
    return render_template(url_for('blueprint.srie_tp4_gaining_access')+'.html', username=username)

def srie_tp4_ssh():
    form = SSHForm()
    ssh_result = None
    success = False

    if form.validate_on_submit():
        target = form.target.data
        username = form.username.data
        try:
            # Dry run pour simuler la connexion SSH
            ssh_result = subprocess.getoutput(f"ssh -o BatchMode=yes {username}@{target} exit")
            if "Permission denied" not in ssh_result and "Could not resolve" not in ssh_result:
                success = True
        except Exception as e:
            ssh_result = f"An error occurred: {str(e)}"

    return render_template(
        'srie/tp4_gaining_access/ssh.html',
        form=form,
        command_executed=ssh_result is not None,
        success=success,
        command_output=ssh_result
    )

def srie_tp4_ftp():
    """
    Handles the logic for the FTP connection tool.
    """
    form = FTPForm()
    ftp_result = None
    command_executed = None

    if form.validate_on_submit():
        target = form.target.data
        username = form.username.data
        password = form.password.data
        try:
            # Crée un script temporaire pour exécuter les commandes FTP
            ftp_commands = f"""
open {target}
user {username} {password}
bye
"""
            command_executed = f"ftp -inv {target}"
            # Passe les commandes via un fichier temporaire
            with open("/tmp/ftp_commands.txt", "w") as cmd_file:
                cmd_file.write(ftp_commands)

            # Exécuter la commande FTP avec le fichier de commandes
            ftp_result = subprocess.getoutput(f"ftp -inv < /tmp/ftp_commands.txt")
        except Exception as e:
            ftp_result = f"An error occurred: {str(e)}"

    return render_template(
        'srie/tp4_gaining_access/ftp.html',
        form=form,
        command_executed=command_executed,
        command_output=ftp_result
    )
