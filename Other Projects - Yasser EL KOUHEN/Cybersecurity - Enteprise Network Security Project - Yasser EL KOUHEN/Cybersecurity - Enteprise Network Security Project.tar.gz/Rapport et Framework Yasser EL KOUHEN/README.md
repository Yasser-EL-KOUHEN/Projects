### README: PyFlaSQL Framework

---

#### **Introduction**

PyFlaSQL is a cybersecurity framework designed for penetration testing education at ISMIN (Mines Saint-Etienne). It enables users to experiment with a variety of tools and techniques to identify vulnerabilities, assess security measures, and simulate penetration testing scenarios. The framework is structured into four main phases: Reconnaissance, Scanning Networks, Enumeration, and Gaining Access.

---

#### **Installation Instructions**

Follow these steps to set up and run the PyFlaSQL framework:

---

### **Step 1: Create a Working Environment**

1. Open a terminal and create the necessary directories:
   ```
   mkdir <user_path>/srie
   mkdir <user_path>/srie/pyenvs
   mkdir <user_path>/srie/repos
   ```

2. Set up a Python virtual environment:
   ```
   python3 -m venv <user_path>/srie/pyenvs/pyflasql
   ```

3. If the above command does not work, install the required packages and try again:
   ```
   sudo apt update
   sudo apt install python3-venv
   python3 -m venv <user_path>/srie/pyenvs/pyflasql
   ```

---

### **Step 2: Activate the Environment**

1. Activate the virtual environment:
   ```
   source <user_path>/srie/pyenvs/pyflasql/bin/activate
   ```

2. You should now see a prompt similar to:
   ```
   (pyflasql) …
   ```

---

### **Step 3: Clone the Git Repository**

1. Navigate to the repository directory:
   ```
   cd <user_path>/srie/repos/
   ```

2. Clone the PyFlaSQL repository:
   ```
   git clone https://gitlab.emse.fr/raphael.viera/pyflasql.git
   ```

3. Alternatively, you can access the repository or download it from:
   [PyFlaSQL Repository](https://gitlab.emse.fr/raphael.viera/pyflasql)

4. Navigate to the project directory:
   ```
   cd pyflasql
   ```

---

### **Step 4: Install Dependencies**

1. Install the required Python packages:
   ```
   pip3 install -r requirements.txt
   ```

---

### **Step 5: Optional Tools Installation**

Some tools require system-level installations. Install them using the following commands:

- **Netcat**:
  ```
  sudo apt install netcat
  ```

- **Telnet**:
  ```
  sudo apt install telnet
  ```

- **Enum4Linux**:
  ```
  sudo apt install enum4linux
  ```

- **nbtscan**:
  ```
  sudo apt install nbtscan
  ```

- **dig**:
  ```
  sudo apt install dnsutils
  ```

---

### **Step 6: Run the Framework**

1. Start the application:
   ```
   python3 run.py
   ```

2. Open the framework in a web browser:
   ```
   http://127.0.0.1:4990
   ```

   > Note: You can change the port in the `run.py` file if needed.

3. Register a new user to access the framework. There is no predefined user as the database is initially empty.

---

#### **Implemented Tools**

The framework includes tools grouped by penetration testing phases:

---

### **1. SRIE > TP1 - Reconnaissance / Footprint**
**Goal**: Gather information about the target system to assess its security posture.

- **IP Addresses (Private and Public)**:
  Retrieve the private and public IP addresses of devices.
- **WHOIS**:
  Obtain registration details for domains or IP addresses.
- **DNS Lookup**:
  Use `dig` to retrieve DNS records for a target domain.

---

### **2. SRIE > TP2 - Scanning Networks**
**Goal**: Identify active devices, open ports, and potential vulnerabilities.

- **Ping an IP Address**:
  Send ICMP Echo Request packets to test connectivity and response time.
- **Traceroute**:
  Map the path packets take to reach a target system and analyze network routing.
- **Netcat**:
  A versatile tool for scanning open ports, listening on ports, and transferring data.

---

### **3. SRIE > TP3 - Enumeration**
**Goal**: Gather detailed information about the target system, including users, services, and shares.

- **Enum4Linux**:
  Retrieve detailed information from Windows systems using Samba.
- **NetBIOS Scan**:
  Use `nbtscan` to discover hostnames and workgroups in a network.
- **Banner Grabbing (Telnet)**:
  Connect to a service via Telnet to retrieve service banners.

---

### **4. SRIE > TP4 - Gaining Access**
**Goal**: Simulate exploitation of vulnerabilities to gain unauthorized access to systems.

- **SSH Connection**:
  Establish a secure shell connection to the target machine.
- **FTP Connection**:
  Test access to an FTP server by providing credentials.

---

#### **Usage Notes**

1. **Authorization**:
   Always obtain explicit permission before using this framework in a network environment.
2. **Ethics**:
   This tool is for educational purposes only. Misuse for malicious purposes is illegal.
3. **Documentation**:
   Refer to the lab guides and tooltips within the framework for detailed usage instructions.

---

#### **Contact**

For issues or contributions, please contact:  
**Raphael Viera** - [raphael.viera@emse.fr]  
**ISMIN Student Yasser El Kouhen** - [yasserelkouhen5@gmail.com]  

--- 

Enjoy exploring and enhancing your cybersecurity skills with PyFlaSQL! 